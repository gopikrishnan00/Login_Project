﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CrudInGridView
{
    public partial class redirected : System.Web.UI.Page
    {

        string connectionString = "Data Source=75.148.178.12;Initial Catalog=Book;User ID=sa;Password=H0u$t0n77042;";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["PhoneBookID"] != null)
                {
                    int id = Convert.ToInt32(Request.QueryString["PhoneBookID"]);
                    LoadData(id);
                }
            }

        }



        protected void Button1_Click(object sender, EventArgs e)
        {
            string imagePath = Server.MapPath("~/Image1/");
            if (!Directory.Exists(imagePath))
            {
                Directory.CreateDirectory(imagePath);
            }

            string imageName = Path.GetFileName(images1.PostedFile.FileName);
            string savePath = Path.Combine(imagePath, imageName);
            images1.PostedFile.SaveAs(savePath);


            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                string query = "insert into  phoneBook (FirstName, LastName, Contact, Email, Images) values (@FirstName, @LastName, @Contact,@Email, @Images)";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                sqlCmd.Parameters.AddWithValue("@FirstName", fname2.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@LastName", lname2.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@Contact", contact2.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@Email", email2.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@Images", "Image1/" + imageName);
                sqlCmd.ExecuteNonQuery();
            }

            Response.Redirect("~/Default.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(Request.QueryString["PhoneBookID"]);

            string imagePath = Server.MapPath("~/Image1/");
            if (!Directory.Exists(imagePath))
            {
                Directory.CreateDirectory(imagePath);
            }

            string imageName = Path.GetFileName(images1.PostedFile.FileName);
            string savePath = Path.Combine(imagePath, imageName);
            images1.PostedFile.SaveAs(savePath);

            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                string query = "update phoneBook  set FirstName = @FirstName, LastName = @LastName, Contact = @Contact, Email = @Email,Images = @Images where PhoneBookID = @ID";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                sqlCmd.Parameters.AddWithValue("@FirstName", fname2.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@LastName", lname2.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@Contact", contact2.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@Email", email2.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@Images", "Image1/" + imageName);
                sqlCmd.Parameters.AddWithValue("@ID", id);
                sqlCmd.ExecuteNonQuery();
            }
            Response.Redirect("~/Default.aspx");
        }



        private void LoadData(int id)
        {
            if (Request.QueryString["PhoneBookID"] != null)
            {

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    SqlCommand cmd = new SqlCommand("select * FROM phoneBook  WHERE PhoneBookID = @ID", connection);

                    cmd.Parameters.AddWithValue("@ID", id);

                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        fname2.Text = reader["FirstName"].ToString();
                        lname2.Text = reader["LastName"].ToString();
                        contact2.Text = reader["Contact"].ToString();
                        email2.Text = reader["Email"].ToString();


                        string imagePath = reader["Images"].ToString();
                        if (!string.IsNullOrEmpty(imagePath))
                        {
                            imgPreview.ImageUrl = imagePath;
                            ViewState["savePath"] = imagePath;
                        }


                    }
                }
            }
        }

    }
}